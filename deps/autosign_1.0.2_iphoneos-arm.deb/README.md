# AutoSign

Automatically signs binaries when installed with dpkg/apt.

# How does this work?

This hijacks dpkg to run a script before running the real dpkg. The script resigns the deb, and can be found in `/usr/bin/resign_deb.sh`.
